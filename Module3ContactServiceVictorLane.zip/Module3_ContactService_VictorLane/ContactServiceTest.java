/*
 * File: ContactServiceTest.java
 * Author: Victor Lane
 * Date: 31 March 2026
 * Description:
 * Tests the ContactService class to make sure contacts can be added,
 *  retrieved, updated, and deleted correctly. It also checks that invalid actions,
 *  like using duplicate IDs, missing contacts, or null values, are handled properly
 *  by throwing errors.
 *
 * Method Overview
 * ----------------
 * testAddContact()                        - Tests adding a valid contact and retrieving it
 * testAddDuplicateContactId()             - Tests that duplicate contact IDs throw an exception
 * testDeleteContact()                     - Tests deleting an existing contact
 * testUpdateFirstName()                   - Tests updating a contact's first name
 * testUpdateLastName()                    - Tests updating a contact's last name
 * testUpdatePhone()                       - Tests updating a contact's phone number
 * testUpdateAddress()                     - Tests updating a contact's address
 * testDeleteMissingContactThrowsException() - Tests deleting a non-existent contact throws an exception
 * testGetMissingContactThrowsException()  - Tests retrieving a non-existent contact throws an exception
 * testNullAddContact()                    - Tests adding a null contact throws an exception
 */

package com.contact_services;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import org.junit.jupiter.api.Test;

public class ContactServiceTest {

    @Test
    public void testAddContact() {
        ContactService service = new ContactService();
        Contact contact = new Contact("123", "Victor", "Lane", "1234567890", "123 Main St");

        service.addContact(contact);

        assertEquals(contact, service.getContact("123"));
    }

    @Test
    public void testAddDuplicateContactId() {
        ContactService service = new ContactService();
        Contact contact1 = new Contact("123", "Victor", "Lane", "1234567890", "123 Main St");
        Contact contact2 = new Contact("123", "John", "Smith", "0987654321", "456 Oak St");

        service.addContact(contact1);

        assertThrows(IllegalArgumentException.class, () ->
            service.addContact(contact2)
        );
    }

    @Test
    public void testDeleteContact() {
        ContactService service = new ContactService();
        Contact contact = new Contact("123", "Victor", "Lane", "1234567890", "123 Main St");

        service.addContact(contact);
        service.deleteContact("123");

        assertThrows(IllegalArgumentException.class, () ->
            service.getContact("123")
        );
    }

    @Test
    public void testUpdateFirstName() {
        ContactService service = new ContactService();
        Contact contact = new Contact("123", "Victor", "Lane", "1234567890", "123 Main St");

        service.addContact(contact);
        service.updateFirstName("123", "Vic");

        assertEquals("Vic", service.getContact("123").getFirstName());
    }

    @Test
    public void testUpdateLastName() {
        ContactService service = new ContactService();
        Contact contact = new Contact("123", "Victor", "Lane", "1234567890", "123 Main St");

        service.addContact(contact);
        service.updateLastName("123", "Smith");

        assertEquals("Smith", service.getContact("123").getLastName());
    }

    @Test
    public void testUpdatePhone() {
        ContactService service = new ContactService();
        Contact contact = new Contact("123", "Victor", "Lane", "1234567890", "123 Main St");

        service.addContact(contact);
        service.updatePhone("123", "0987654321");

        assertEquals("0987654321", service.getContact("123").getPhone());
    }

    @Test
    public void testUpdateAddress() {
        ContactService service = new ContactService();
        Contact contact = new Contact("123", "Victor", "Lane", "1234567890", "123 Main St");

        service.addContact(contact);
        service.updateAddress("123", "456 Oak Street");

        assertEquals("456 Oak Street", service.getContact("123").getAddress());
    }

    @Test
    public void testDeleteMissingContactThrowsException() {
        ContactService service = new ContactService();

        assertThrows(IllegalArgumentException.class, () ->
            service.deleteContact("999")
        );
    }

    @Test
    public void testGetMissingContactThrowsException() {
        ContactService service = new ContactService();

        assertThrows(IllegalArgumentException.class, () ->
            service.getContact("999")
        );
    }

    @Test
    public void testNullAddContact() {
        ContactService service = new ContactService();

        assertThrows(IllegalArgumentException.class, () -> {
            service.addContact(null);
        });
    }
}