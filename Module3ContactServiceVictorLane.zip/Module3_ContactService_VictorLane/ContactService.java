/*
 * File: ContactService.java
 * Author: Victor Lane
 * Date: 31 March 2026
 * Description:
 * Manages a list of contacts stored in memory. Allows contacts to be added, 
 * removed, viewed, and updated while making sure each contact has a unique ID and all data is valid.
 *
 * Method Overview
 * ----------------
 * addContact()        - Adds a new contact if not null and ID is unique
 * deleteContact()     - Deletes a contact by ID if it exists
 * updateFirstName()   - Updates the first name of a contact by ID
 * updateLastName()    - Updates the last name of a contact by ID
 * updatePhone()       - Updates the phone number of a contact by ID
 * updateAddress()     - Updates the address of a contact by ID
 * getContact()        - Retrieves a contact by ID, throws exception if not found
 */

package com.contact_services;

import java.util.HashMap;
import java.util.Map;

public class ContactService {
    private final Map<String, Contact> contacts = new HashMap<>();

    public void addContact(Contact contact) {
        if (contact == null) {
            throw new IllegalArgumentException("Contact cannot be null");
        }

        if (contacts.containsKey(contact.getContactId())) {
            throw new IllegalArgumentException("Contact ID already exists");
        }

        contacts.put(contact.getContactId(), contact);
    }

    public void deleteContact(String contactId) {
        if (!contacts.containsKey(contactId)) {
            throw new IllegalArgumentException("Contact ID not found");
        }

        contacts.remove(contactId);
    }

    public void updateFirstName(String contactId, String firstName) {
        Contact contact = getContact(contactId);
        contact.setFirstName(firstName);
    }

    public void updateLastName(String contactId, String lastName) {
        Contact contact = getContact(contactId);
        contact.setLastName(lastName);
    }

    public void updatePhone(String contactId, String phone) {
        Contact contact = getContact(contactId);
        contact.setPhone(phone);
    }

    public void updateAddress(String contactId, String address) {
        Contact contact = getContact(contactId);
        contact.setAddress(address);
    }

    public Contact getContact(String contactId) {
        if (!contacts.containsKey(contactId)) {
            throw new IllegalArgumentException("Contact ID not found");
        }

        return contacts.get(contactId);
    }
}