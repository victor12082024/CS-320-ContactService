/*
 * File: ContactTest.java
 * Author: Victor Lane
 * Date: 31 March 2026
 * Description:
 * Tests the Contact class to verify that valid contact objects can be created
 * and that invalid values correctly throw exceptions. Also tests getter and
 * setter methods to make sure contact data is stored and updated correctly.
 *
 * Method Overview
 * ----------------
 * testValidContactCreation()   - Tests that a valid contact is created correctly
 * testInvalidContactIdTooLong() - Tests that a contact ID over 10 characters throws an exception
 * testInvalidFirstNameTooLong() - Tests that a first name over 10 characters throws an exception
 * testInvalidLastNameTooLong() - Tests that a last name over 10 characters throws an exception
 * testInvalidPhone()           - Tests that an invalid phone number throws an exception
 * testInvalidAddressTooLong()  - Tests that an address over 30 characters throws an exception
 * testSetFirstName()           - Tests updating the first name
 * testSetLastName()            - Tests updating the last name
 * testSetPhone()               - Tests updating the phone number
 * testSetAddress()             - Tests updating the address
 * testFirstNameNull()          - Tests that a null first name throws an exception
 * testLastNameNull()           - Tests that a null last name throws an exception
 * testContactIdNull()          - Tests that a null contact ID throws an exception
 * testPhoneNull()              - Tests that a null phone number throws an exception
 * testAddressNull()            - Tests that a null address throws an exception
 */

package com.contact_services;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import org.junit.jupiter.api.Test;

public class ContactTest {

    @Test
    public void testValidContactCreation() {
        Contact contact = new Contact("123", "Victor", "Lane", "1234567890", "123 Main St");

        assertEquals("123", contact.getContactId());
        assertEquals("Victor", contact.getFirstName());
        assertEquals("Lane", contact.getLastName());
        assertEquals("1234567890", contact.getPhone());
        assertEquals("123 Main St", contact.getAddress());
    }

    @Test
    public void testInvalidContactIdTooLong() {
        assertThrows(IllegalArgumentException.class, () ->
            new Contact("12345678901", "Victor", "Lane", "1234567890", "123 Main St")
        );
    }

    @Test
    public void testInvalidFirstNameTooLong() {
        assertThrows(IllegalArgumentException.class, () ->
            new Contact("123", "VeryLongName", "Lane", "1234567890", "123 Main St")
        );
    }

    @Test
    public void testInvalidLastNameTooLong() {
        assertThrows(IllegalArgumentException.class, () ->
            new Contact("123", "Victor", "VeryLongName", "1234567890", "123 Main St")
        );
    }

    @Test
    public void testInvalidPhone() {
        assertThrows(IllegalArgumentException.class, () ->
            new Contact("123", "Victor", "Lane", "12345", "123 Main St")
        );
    }

    @Test
    public void testInvalidAddressTooLong() {
        assertThrows(IllegalArgumentException.class, () ->
            new Contact("123", "Victor", "Lane", "1234567890", "1234567890123456789012345678901")
        );
    }

    @Test
    public void testSetFirstName() {
        Contact contact = new Contact("123", "Victor", "Lane", "1234567890", "123 Main St");
        contact.setFirstName("Vic");
        assertEquals("Vic", contact.getFirstName());
    }

    @Test
    public void testSetLastName() {
        Contact contact = new Contact("123", "Victor", "Lane", "1234567890", "123 Main St");
        contact.setLastName("Smith");
        assertEquals("Smith", contact.getLastName());
    }

    @Test
    public void testSetPhone() {
        Contact contact = new Contact("123", "Victor", "Lane", "1234567890", "123 Main St");
        contact.setPhone("0987654321");
        assertEquals("0987654321", contact.getPhone());
    }

    @Test
    public void testSetAddress() {
        Contact contact = new Contact("123", "Victor", "Lane", "1234567890", "123 Main St");
        contact.setAddress("456 Oak Street");
        assertEquals("456 Oak Street", contact.getAddress());
    }

    // Can't be null checks

    @Test
    public void testFirstNameNull() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", null, "Sam", "1234567890", "123 Main St");
        });

        assertEquals("Invalid first name", exception.getMessage());
    }

    @Test
    public void testLastNameNull() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "Victor", null, "1234567890", "123 Main St");
        });

        assertEquals("Invalid last name", exception.getMessage());
    }

    @Test
    public void testContactIdNull() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Contact(null, "Victor", "Lane", "1234567890", "123 Main St");
        });

        assertEquals("Invalid contactId", exception.getMessage());
    }

    @Test
    public void testPhoneNull() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "Victor", "Lane", null, "123 Main St");
        });

        assertEquals("Invalid phone", exception.getMessage());
    }

    @Test
    public void testAddressNull() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "Victor", "Lane", "1234567890", null);
        });

        assertEquals("Invalid address", exception.getMessage());
    }
}